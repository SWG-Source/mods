No MustaMovie MOD1.0
Modification for SWG
by Powerking89670 aka "Fotineet" of Naritus

TABLE OF CONTENTS
I.   INTRODUCTION
II.  INSTALLATION
III. VERSION HISTORY

I. INTRODUCTION
This movie completely disables the Mustafar Movie you see every time u goto Mustafar or Clone on Mustafar. Thanks Go out to Uli for locateing the correct file. This Mod is exclusive to Mod Source. Meaning that it can only be obtained from Mod Source http://mods.mandalorians.de if you got it anyware else please inform Powerking89670 of Mod Source or one of the Mod Source Admins. And lastly this file is client side meaning it only affects you!

II. INSTALLATION
To install this mod, use an archiving utility such as Winzip or WinRAR to extract the files
in this ZIP archive to your main SWG directory (usually C:\Program Files\Star Wars Galaxies).
Start the game and enjoy!

Note: This mod will put folders with some files in the game directory that will be 
used instead of the files in the game. No actual SWG game files will be overwritten. You can 
only run part of the files or all of them at once for the full experience. Read section three 
on which files do what. Feel free to simply rename or delete the files you do not wish to use 
from the appropriate folder of your SWG directory.
To uninstall the mod, simply remove the files/folders that you extracted from the SWG 
directory.


III. VERSION HISTORY

Version 1.0 (Released April 23, 2006)
- initial release

The following files have been included in this archive:

README.txt		This FIle

/Video                          The Folder in which the mod is in

Install.exe                        A simple way to install the mod

----------------------------------------------------------------------------------------------
DISCLAIMER: The author(s) of these files do not accept any responsibility for anything related 
to them. Use at your own risk! Please ask the author(s) if you want to use these files for 
anything else.