Basic Dance to Breakdance Floor Flourishes MOd 1.0
Modification for SWG
by Medusa

--------------------------------------------------------------------------------------
TABLE OF CONTENTS
I.    INTRODUCTION
II.   INSTALLATION
III.  UNINSTALLATION
IV.   VERSION HISTORY
V.    INCLUDED FILES
VI.   KNOWN ISSUES
VII. CREDITS
--------------------------------------------------------------------------------------

I. INTRODUCTION

This client-side modification changes the rather goofy looking basic dance 
(available to all players) to a breakdance with floor flourishes not seen before in game.

To use:
Type the command /startdance then type one of the following flourish commands: 
/flo 1 /flo 2 /flo 3 /flo 4 /flo 5 /flo 6 /flo 7 or /flo 8

Note: The flourish commands can also be made into individual macros or one complete macro 
with /pause commands in between.

***This mod is usable by all players, not just entertainers/dancers***  

--------------------------------------------------------------------------------------

II. INSTALLATION

To install this mod, use an archiving utility such as Winzip or WinRAR to extract the files 
in this ZIP archive to your main SWG directory (usually C:\Program Files\Star Wars Galaxies).

Note: This mod will put folders with some files in the game directory that will be used 
instead of the files in the game. No actual SWG game files will be overwritten. You can 
only run part of the files or all of them at once for the full experience. Read section 
three on which files do what. Feel free to simply rename or delete the files you do not 
wish to use from the appropriate folder of your SWG directory. 

--------------------------------------------------------------------------------------

III. UNINSTALLATION

To uninstall the mod, simply remove the files/folders that you extracted from your 
SWG directory.

--------------------------------------------------------------------------------------

IV. VERSION HISTORY

Version 1.0 (Released June 25, 2006)
- initial release

--------------------------------------------------------------------------------------

V. INCLUDED FILES

The following files have been included in this archive:

Read_me.txt			This text file

\appearance\animation
all_b_dnc_goofy_sp*.ans   	Changes the basic dance animations to breakdance with 
				floor flourishes (not seen before in game)

--------------------------------------------------------------------------------------
VI. KNOWN ISSUES

- No issues are currently known.
--------------------------------------------------------------------------------------
VII. CREDITS
Thanks go out to all the modders out there that have actively or passively contributed to 
this mod!  Special thanks to the people at ModSource - YOUR source for SWG 
modding stuff (mods.mandalorians.de) for initially hosting this mod.
--------------------------------------------------------------------------------------
DISCLAIMER: The author(s) of these files do not accept any responsibility for anything 
related to them. Use at your own risk! Please ask the respective author(s) 
for permission if you want to use these files for anything else.
