astromech_2_Hailfire 1.0
Modification for SWG
by DavinFelth
------------------------------------
TABLE OF CONTENTS
I. INTRODUCTION
II. INSTALLATION
III. UNINSTALLATION
IV. VERSION HISTORY
V. INCLUDED FILES
VI. KNOWN ISSUES
VII. MISCELLANEOUS
VIII. CREDITS
------------------------------------
I. INTRODUCTION
This is a mod that will change your astromech droids appearance into 
that of the hailfire droid.
------------------------------------
------------------------------------
II. INSTALLATION
First, you have to uninstall any previous conflicting Mods that you
may have used. Otherwise there may be serious compatibility issues.
To install this mod, use an archiving utility such as Winzip, ExtractNow!
or WinRAR to extract the files from this ZIP or RAR archive to your main
SWG directory (usually C:\Program Files\Star Wars Galaxies).
Make sure to uninstall any old or incompatible versions of mods first
(see section III. of this readme for instructions on how to do it).

The mod is currently set to change the appearance of an r2 droid 
(astromech_r2.sat) however it can be changed to any type of astromech easily
by changing the file name:-
astromech_r2.sat - R2 Unit
astromech_r3.sat - R3 Unit
astromech_r4.sat - R4 Unit
astromech_r5.sat - R5 Unit
(retty self explanitory really :P)
Start the game and enjoy!

Note: This mod will put folders with some files in the game directory
that will be used instead of the files in the game. No actual SWG game
files will be overwritten. You can only run part of the files or all of
them at once for the full experience. Read section three on which files
do what. Feel free to simply rename or delete the files you do not wish
to use from the appropriate folder of your SWG directory.
------------------------------------
III. UNINSTALLATION
To uninstall the mod, simply remove the files/folders that you extracted
at the installation of the Mod from your SWG directory.
Keep this readme file inside the SWG Folder in case you forget which
files have been installed with which mod and see section V. of this
readme for details on files included with this mod.
------------------------------------
IV. VERSION HISTORY

Version 1.00 (Released January 1st, 2007)
- initial release
------------------------------------
V. INCLUDED FILES

The following files have been included in this archive:

ReadMetxt Readme file

appearance/astromech_r2.sat
------------------------------------
VI. KNOWN ISSUES
- No issues are currently known.
------------------------------------
VII. MISCELLANEOUS
This has only been tested on an R5 droid but should work on the others 
without trouble.
------------------------------------
VIII. CREDITS
Thanks go out to all the modders out there that have actively or
passively contributed to this mod!
Special thanks to the people at ModSource - YOUR source for SWG
modding stuff (mods.mandalorians.de) for initially hosting this mod.
Also thanks to SWGEmu (swgemu.com) & eXiled (spraticnet.com)
------------------------------------
DISCLAIMER: The author(s) of these files do not accept any
responsibility for anything related to them. Use at your own risk!
Please ask the respective author(s) for permission if you want to
use these files for anything else.