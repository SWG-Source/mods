*************************************************
* AUTHOR: LANGELUSSE                            *
* CREATOR: 24, september 2019                   *
* site: SWGemu.fr				*
*************************************************



These are the functional vehicles on the pre-cu Aurora server (swgemu.fr). Based on the work of EQsanctum and bloodfin.  There are 10 vehicles.
The fluorescent speeder barc's had draftschematics and loots schematics. I used the last update of SWGSource for datables and adding the crc object.

You just need to develop the server side code to add them.